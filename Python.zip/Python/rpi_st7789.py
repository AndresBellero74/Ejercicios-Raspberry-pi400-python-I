from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont
import time

import ST7789  
display=ST7789.ST7789(port=0,cs=0,rst=6,dc=5,backlight=4,spi_speed_hz=10000000)  
display._spi.mode=3  
display.reset()  
display._init()  
image=Image.new('RGB',(240,240),(255,0,0))  #('RGB',(240,240),(r,g,b))
display.display(image)  
time.sleep(2)  
image=Image.open("cat.jpg")  
image=image.resize((240,240),resample=Image.LANCZOS)  
display.display(image)  
