import time
import busio
import spidev
import digitalio
from board import SCK, MOSI, MISO, CE0, D18, D23
from adafruit_rgb_display import color565
import adafruit_rgb_display.ili9341 as ili9341
from gpiozero import LED
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont

# Configuration for CS and DC pins:
CS_PIN = CE0
DC_PIN = D18
RST_PIN = D23
led = LED(21)

spiPort0 = spidev.SpiDev()
spiPort0.open(0,0)
spiPort0.max_speed_hz = 100000

# Setup SPI bus using hardware SPI:
spi = busio.SPI(clock=SCK, MOSI=MOSI, MISO=MISO)


led.off()
time.sleep(2)
led.on()
print(spi)
# Create the ILI9341 display:
display = ili9341.ILI9341(spi, cs=digitalio.DigitalInOut(CS_PIN),
                          dc=digitalio.DigitalInOut(DC_PIN), rst=digitalio.DigitalInOut(RST_PIN))

# Main loop:
while True:
    # Clear the display
    display.fill(0)
    # Draw a red pixel in the center.
    display.pixel(120, 160, color565(255, 0, 0))
    # Pause 2 seconds.
    time.sleep(2)
    # Clear the screen blue.
    display.fill(color565(0, 0, 255))
    # Pause 2 seconds.
    time.sleep(2)
    
    image=Image.new('RGB',(240,240),(255,0,0))  #('RGB',(240,240),(r,g,b))
    
    display.draw(image)  
    time.sleep(2)  
    image=Image.open("cat.jpg")  
    image=image.resize((240,240),resample=Image.LANCZOS)  
    display.display(image)